-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2022 at 06:51 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile_shopping`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `admincheck` (IN `em` VARCHAR(300), IN `pd` VARCHAR(10), OUT `ct` INT)  select count(*) into ct from admin where email=em and pwd=pd$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `checkuser` (IN `em` VARCHAR(300), IN `pd` VARCHAR(10), OUT `ct` INT)  select count(*) into ct from customerdetails where cusemail=em and cuspass=pd$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pwd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `pwd`) VALUES
(1, 'admin@shopping.com', 1234);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `prid` int(11) NOT NULL,
  `pic` varchar(1000) NOT NULL,
  `prnm` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `mail` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`prid`, `pic`, `prnm`, `qty`, `price`, `mail`) VALUES
(38, 'samsung.png', 'samsung galaxy S22 ultra', 1, 109999, 'dinesh@1234');

-- --------------------------------------------------------

--
-- Table structure for table `customerdetails`
--

CREATE TABLE `customerdetails` (
  `cusid` int(11) NOT NULL,
  `cusnm` varchar(100) NOT NULL,
  `cusmob` varchar(100) NOT NULL,
  `cusemail` varchar(100) NOT NULL,
  `cusgender` varchar(100) NOT NULL,
  `cusaddress` mediumtext NOT NULL,
  `cuspincode` int(11) NOT NULL,
  `cuspass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerdetails`
--

INSERT INTO `customerdetails` (`cusid`, `cusnm`, `cusmob`, `cusemail`, `cusgender`, `cusaddress`, `cuspincode`, `cuspass`) VALUES
(0, 'no user', '.', '.', '.', '.', 0, 0),
(1, 'dinesh', '9585159234', 'dinesh@1234', 'male', 'dubai main road,\r\ndubai cross street,\r\ndubai.', 404505, 1234),
(2, 'raju', '3445467', 'raju@1234', 'male', 'singapore main road,\r\nsingapore.', 57789, 1234),
(4, 'hari', '9009887765', 'hari@gmail.com', 'male', '8/100,salem main road,\r\nsalem.\r\n', 90905, 78900),
(5, 'tanu', '23456789', 'tanu@gmail.com', 'female', '5/cross heaven road,\r\nbombay.\r\n', 906780, 1234),
(6, 'luna', '997866454', 'luna@gmail.com', 'female', '123/chennai main road,\r\nchennai cross street,\r\nchennai.', 56779, 1234),
(7, 'lucky', '90004672111', 'lucky@gmail.com', 'female', '123/london main road,\r\nlondon.', 906780, 1234);

-- --------------------------------------------------------

--
-- Table structure for table `order_db`
--

CREATE TABLE `order_db` (
  `orid` int(11) NOT NULL,
  `prid` int(11) NOT NULL,
  `cusnm` varchar(20) NOT NULL,
  `prnm` varchar(30) NOT NULL,
  `cusemail` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `cusaddress` mediumtext NOT NULL,
  `cuspincode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_db`
--

INSERT INTO `order_db` (`orid`, `prid`, `cusnm`, `prnm`, `cusemail`, `price`, `cusaddress`, `cuspincode`) VALUES
(2, 4, 'dinesh', 'samsung galaxy S22 ultra', 'dinesh@1234', 109999, 'dubai main road,\r\ndubai cross street,\r\ndubai.', 404505),
(9, 4, 'dinesh', 'samsung galaxy S22 ultra', 'dinesh@1234', 109999, 'dubai main road,\r\ndubai cross street,\r\ndubai.', 404505);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `prid` int(11) NOT NULL,
  `prnm` varchar(100) NOT NULL,
  `prbr` varchar(100) NOT NULL,
  `pic` varchar(1000) NOT NULL,
  `description` longtext NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `spec` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`prid`, `prnm`, `prbr`, `pic`, `description`, `price`, `qty`, `spec`) VALUES
(1, 'oneplus 9', 'oneplus', 'oneplus2.png', 'latest mobile', 49900, 1, ''),
(3, 'apple iphone 13pro', 'apple', 'apple.png', '.', 129900, 1, ''),
(4, 'samsung galaxy S22 ultra', 'samsung', 'samsung.png', 'Galaxy is first 4nm processor\r\nOur fastest, most powerful chip ever. That means, a faster CPU and GPU compared to Galaxy S21 Ultra. It is an epic leap for smartphone technology.\r\nVision Booster technology defies daylight\r\nThe Dynamic AMOLED 2x display improves outdoor visibility with up to 1750 nits in peak brightness.*** So, when you are outside in the glare of bright sunlight, your screen is still viewable.\r\nFast charge that lasts all day and more\r\nWith an all-day* battery and superfast charging, a single, superfast 45W** charge gives you more than a full day of power\r\nMake nights epic with Nightography\r\nIt?s our brightest innovation yet. The sensor pulls in more light, the Super Clear Lens tones down lens flare, and fast-acting AI delivers near-instant intelligent processing.\r\nSmooth video in every take\r\nSuper Steady corrects camera shake at a wider angle and tracks multiple objects to stabilize motion, banishing blur from each frame. Super HDR displays 64x more color.\r\nThe first Galaxy S with embedded S Pen\r\nWe?ve given the S pen even more power. Write comfortably like pen on paper, turn quick notes into legible text and use Air Actions to control your phone remotely.', 109999, 1, 'Display:\r\n6.80-inch,\r\nProcessor:\r\nQualcomm Snapdragon 8 Gen 1\r\nFront Camera:\r\n40MP\r\nRear Camera:\r\n108MP + 12MP + 10MP\r\nRAM:\r\n12GB\r\nStorage:\r\n1TB\r\nBattery Capacity:\r\n5000mAh\r\nOS:\r\nAndroid 12.'),
(5, 'redmi note 11T 5G', 'Mi', 'redmi.png', '.', 18999, 1, ''),
(6, 'oppo Reno 7 pro', 'oppo', 'oppo2.png', '.', 38729, 1, ''),
(7, 'vivo X60 pro+', 'vivo', 'vivo.png', '.', 55079, 1, ''),
(8, 'realme Gt 5G', 'realme', 'realme2.png', '.', 40499, 1, ''),
(12, 'Nokia XR20 5G', 'Nokia', 'nokia2.png', '.', 46998, 1, '.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`prid`);

--
-- Indexes for table `customerdetails`
--
ALTER TABLE `customerdetails`
  ADD PRIMARY KEY (`cusid`);

--
-- Indexes for table `order_db`
--
ALTER TABLE `order_db`
  ADD PRIMARY KEY (`orid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`prid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `customerdetails`
--
ALTER TABLE `customerdetails`
  MODIFY `cusid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_db`
--
ALTER TABLE `order_db`
  MODIFY `orid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
